const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

app.use(express.static(__dirname));

const rooms = {};

function generateRoomId() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function createRoom() {
    const roomId = generateRoomId();
    rooms[roomId] = {
        players: [],
        board: Array(15).fill(null).map(() => Array(15).fill(0)),
        currentPlayer: 1,
        gameOver: false,
        winner: null
    };
    return roomId;
}

io.on('connection', (socket) => {
    console.log('用户连接:', socket.id);

    socket.on('createRoom', () => {
        const roomId = createRoom();
        rooms[roomId].players.push({ id: socket.id, role: 'black' });
        socket.join(roomId);
        socket.emit('roomCreated', { roomId });
        console.log(`房间创建: ${roomId}, 创建者: ${socket.id}`);
    });

    socket.on('joinRoom', (roomId) => {
        if (!rooms[roomId]) {
            socket.emit('error', '房间不存在');
            return;
        }
        if (rooms[roomId].players.length >= 2) {
            socket.emit('error', '房间已满');
            return;
        }
        
        rooms[roomId].players.push({ id: socket.id, role: 'white' });
        socket.join(roomId);
        
        socket.emit('joinedRoom', { 
            roomId, 
            role: 'white',
            board: rooms[roomId].board,
            currentPlayer: rooms[roomId].currentPlayer
        });
        
        io.to(roomId).emit('playerJoined', { 
            roomId,
            board: rooms[roomId].board,
            currentPlayer: rooms[roomId].currentPlayer
        });
        
        console.log(`玩家加入房间: ${roomId}, 玩家: ${socket.id}`);
    });

    socket.on('makeMove', (data) => {
        const { roomId, row, col } = data;
        if (!rooms[roomId]) return;
        
        const room = rooms[roomId];
        if (room.board[row][col] !== 0 || room.gameOver) return;
        
        const player = room.players.find(p => p.id === socket.id);
        if (!player) return;
        
        const playerNum = player.role === 'black' ? 1 : 2;
        if (room.currentPlayer !== playerNum) return;
        
        room.board[row][col] = playerNum;
        
        if (checkWin(room.board, row, col, playerNum)) {
            room.gameOver = true;
            room.winner = playerNum;
            io.to(roomId).emit('gameEnd', { 
                winner: playerNum,
                board: room.board
            });
        } else if (isBoardFull(room.board)) {
            room.gameOver = true;
            room.winner = null;
            io.to(roomId).emit('gameEnd', { 
                winner: null,
                board: room.board
            });
        } else {
            room.currentPlayer = playerNum === 1 ? 2 : 1;
            io.to(roomId).emit('moveMade', { 
                row, 
                col, 
                player: playerNum,
                currentPlayer: room.currentPlayer
            });
        }
    });

    socket.on('restartGame', (roomId) => {
        if (!rooms[roomId]) return;
        
        rooms[roomId].board = Array(15).fill(null).map(() => Array(15).fill(0));
        rooms[roomId].currentPlayer = 1;
        rooms[roomId].gameOver = false;
        rooms[roomId].winner = null;
        
        io.to(roomId).emit('gameRestarted', { 
            board: rooms[roomId].board,
            currentPlayer: rooms[roomId].currentPlayer
        });
    });

    socket.on('leaveRoom', (roomId) => {
        if (!rooms[roomId]) return;
        
        rooms[roomId].players = rooms[roomId].players.filter(p => p.id !== socket.id);
        
        if (rooms[roomId].players.length === 0) {
            delete rooms[roomId];
        } else {
            io.to(roomId).emit('playerLeft');
        }
        
        socket.leave(roomId);
        console.log(`玩家离开房间: ${roomId}, 玩家: ${socket.id}`);
    });

    socket.on('disconnect', () => {
        console.log('用户断开连接:', socket.id);
        
        for (const roomId in rooms) {
            const room = rooms[roomId];
            const playerIndex = room.players.findIndex(p => p.id === socket.id);
            
            if (playerIndex !== -1) {
                room.players.splice(playerIndex, 1);
                
                if (room.players.length === 0) {
                    delete rooms[roomId];
                } else {
                    io.to(roomId).emit('playerLeft');
                }
                
                break;
            }
        }
    });
});

function checkWin(board, row, col, player) {
    const directions = [[0, 1], [1, 0], [1, 1], [1, -1]];

    for (const [dr, dc] of directions) {
        let count = 1;

        for (let i = 1; i < 5; i++) {
            const newRow = row + dr * i;
            const newCol = col + dc * i;
            if (newRow >= 0 && newRow < 15 && newCol >= 0 && newCol < 15 &&
                board[newRow][newCol] === player) {
                count++;
            } else {
                break;
            }
        }

        for (let i = 1; i < 5; i++) {
            const newRow = row - dr * i;
            const newCol = col - dc * i;
            if (newRow >= 0 && newRow < 15 && newCol >= 0 && newCol < 15 &&
                board[newRow][newCol] === player) {
                count++;
            } else {
                break;
            }
        }

        if (count >= 5) return true;
    }

    return false;
}

function isBoardFull(board) {
    for (let row = 0; row < 15; row++) {
        for (let col = 0; col < 15; col++) {
            if (board[row][col] === 0) return false;
        }
    }
    return true;
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});