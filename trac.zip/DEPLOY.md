# 五子棋对战平台 - 部署指南

## 部署到 Railway（推荐）

Railway 是一个免费的云平台，支持 Node.js 和 WebSocket。

### 步骤 1：上传代码到 GitHub

1. 在 GitHub 创建新仓库
2. 将项目文件夹初始化为 Git 仓库：
   ```bash
   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin https://github.com/你的用户名/gomoku.git
   git push -u origin main
   ```

### 步骤 2：部署到 Railway

1. 访问 https://railway.app 并登录（可用 GitHub 账号）
2. 点击 "New Project" → "Deploy from GitHub repo"
3. 选择刚才创建的仓库
4. Railway 会自动检测 Node.js 项目并部署

### 步骤 3：访问网站

部署完成后，Railway 会提供一个 URL，如：`https://gomoku.up.railway.app`

## 部署到 Render

1. 访问 https://render.com 并注册
2. 点击 "New" → "Web Service"
3. 连接 GitHub 仓库
4. 设置：
   - Build Command: `npm install`
   - Start Command: `npm start`
5. 点击 "Create Web Service"

## 本地测试

本地测试需要分别启动前端和后端：

1. 安装依赖：
   ```bash
   npm install
   ```

2. 启动服务器：
   ```bash
   npm start
   ```

3. 访问 http://localhost:3000

## 功能说明

- **人机对战**：与 AI 对弈，支持三种难度
- **联机对战**：创建房间后，另一人通过房间号加入，实现跨设备对战