const BOARD_SIZE = 15;
const CELL_SIZE = 40;
const PADDING = 20;

const EMPTY = 0;
const BLACK = 1;
const WHITE = 2;

let board = [];
let currentPlayer = BLACK;
let gameOver = false;
let winner = null;
let history = [];
let playerIsBlack = true;
let aiThinking = false;
let isOnlineMode = false;
let isHost = false;
let currentRoomId = null;
let socket = null;
let onlineRole = null;

const canvas = document.getElementById('board');
const ctx = canvas.getContext('2d');

const SERVER_URL = window.location.hostname === 'localhost'
    ? 'http://localhost:3000'
    : window.location.origin;

function initBoard() {
    board = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(EMPTY));
    history = [];
    currentPlayer = BLACK;
    gameOver = false;
    winner = null;
    aiThinking = false;
    updateUI();
    drawBoard();
}

function drawBoard() {
    ctx.fillStyle = '#DEB887';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#5D4037';
    ctx.lineWidth = 1;

    for (let i = 0; i <= BOARD_SIZE; i++) {
        const pos = PADDING + i * CELL_SIZE;
        ctx.beginPath();
        ctx.moveTo(pos, PADDING);
        ctx.lineTo(pos, PADDING + (BOARD_SIZE - 1) * CELL_SIZE);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(PADDING, pos);
        ctx.lineTo(PADDING + (BOARD_SIZE - 1) * CELL_SIZE, pos);
        ctx.stroke();
    }

    const starPoints = [
        [3, 3], [3, 11], [7, 7], [11, 3], [11, 11]
    ];

    ctx.fillStyle = '#5D4037';
    starPoints.forEach(([row, col]) => {
        const x = PADDING + col * CELL_SIZE;
        const y = PADDING + row * CELL_SIZE;
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
    });

    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] !== EMPTY) {
                drawPiece(row, col, board[row][col]);
            }
        }
    }
}

function drawPiece(row, col, player) {
    const x = PADDING + col * CELL_SIZE;
    const y = PADDING + row * CELL_SIZE;

    ctx.beginPath();
    ctx.arc(x, y, 18, 0, Math.PI * 2);

    if (player === BLACK) {
        const gradient = ctx.createRadialGradient(x - 4, y - 4, 0, x, y, 18);
        gradient.addColorStop(0, '#555');
        gradient.addColorStop(1, '#000');
        ctx.fillStyle = gradient;
    } else {
        const gradient = ctx.createRadialGradient(x - 4, y - 4, 0, x, y, 18);
        gradient.addColorStop(0, '#fff');
        gradient.addColorStop(1, '#ddd');
        ctx.fillStyle = gradient;
    }

    ctx.fill();
    ctx.strokeStyle = player === BLACK ? '#000' : '#aaa';
    ctx.lineWidth = 1;
    ctx.stroke();
}

function getClickPosition(event) {
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const col = Math.round((x - PADDING) / CELL_SIZE);
    const row = Math.round((y - PADDING) / CELL_SIZE);

    if (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE) {
        return { row, col };
    }
    return null;
}

function makeMove(row, col, player) {
    if (board[row][col] !== EMPTY || gameOver) return false;

    board[row][col] = player;
    history.push({ row, col, player });

    if (checkWin(row, col, player)) {
        gameOver = true;
        winner = player;
        updateUI();
        drawBoard();
        return true;
    }

    if (history.length === BOARD_SIZE * BOARD_SIZE) {
        gameOver = true;
        winner = null;
        updateUI();
        drawBoard();
        return true;
    }

    currentPlayer = player === BLACK ? WHITE : BLACK;
    updateUI();
    drawBoard();
    return true;
}

function checkWin(row, col, player) {
    const directions = [
        [0, 1],   // 水平
        [1, 0],   // 垂直
        [1, 1],   // 对角线
        [1, -1]   // 反对角线
    ];

    for (const [dr, dc] of directions) {
        let count = 1;

        for (let i = 1; i < 5; i++) {
            const newRow = row + dr * i;
            const newCol = col + dc * i;
            if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE &&
                board[newRow][newCol] === player) {
                count++;
            } else {
                break;
            }
        }

        for (let i = 1; i < 5; i++) {
            const newRow = row - dr * i;
            const newCol = col - dc * i;
            if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE &&
                board[newRow][newCol] === player) {
                count++;
            } else {
                break;
            }
        }

        if (count >= 5) return true;
    }

    return false;
}

function updateUI() {
    const currentPlayerSpan = document.getElementById('current-player');
    const gameStatusSpan = document.getElementById('game-status');
    const playerRoleSpan = document.getElementById('player-role');

    if (gameOver) {
        if (winner === null) {
            gameStatusSpan.textContent = '平局！';
        } else {
            gameStatusSpan.textContent = (winner === BLACK ? '黑方' : '白方') + '获胜！';
        }
        gameStatusSpan.className = 'game-status win';
    } else {
        currentPlayerSpan.textContent = currentPlayer === BLACK ? '黑方' : '白方';
        gameStatusSpan.textContent = '游戏进行中';
        gameStatusSpan.className = 'game-status';
    }

    if (isOnlineMode) {
        playerRoleSpan.textContent = playerIsBlack ? '你执黑棋' : '你执白棋';
    } else {
        playerRoleSpan.textContent = playerIsBlack ? '你执黑棋（先手）' : '你执白棋（后手）';
    }
}

function undo() {
    if (history.length === 0 || gameOver || aiThinking) return;

    const lastMove = history.pop();
    board[lastMove.row][lastMove.col] = EMPTY;
    currentPlayer = lastMove.player;
    gameOver = false;
    winner = null;
    updateUI();
    drawBoard();
}

function changeSide() {
    if (isOnlineMode) {
        alert('联机模式下不能交换先后手！');
        return;
    }
    playerIsBlack = !playerIsBlack;
    initBoard();

    if (!playerIsBlack) {
        setTimeout(() => aiMove(), 500);
    }
}

function aiMove() {
    if (gameOver || aiThinking) return;

    aiThinking = true;

    setTimeout(() => {
        const difficulty = parseInt(document.getElementById('difficulty-select').value);
        const depth = difficulty === 3 ? 4 : (difficulty === 2 ? 3 : 2);
        const bestMove = findBestMove(depth);

        if (bestMove) {
            makeMove(bestMove.row, bestMove.col, playerIsBlack ? WHITE : BLACK);
        }

        aiThinking = false;
    }, 100);
}

function findBestMove(depth) {
    const aiPlayer = playerIsBlack ? WHITE : BLACK;
    const humanPlayer = playerIsBlack ? BLACK : WHITE;

    let bestScore = -Infinity;
    let bestMoves = [];

    const candidates = getCandidates();

    for (const move of candidates) {
        board[move.row][move.col] = aiPlayer;

        if (checkWin(move.row, move.col, aiPlayer)) {
            board[move.row][move.col] = EMPTY;
            return move;
        }

        const score = minimax(depth - 1, -Infinity, Infinity, true, aiPlayer, humanPlayer);
        board[move.row][move.col] = EMPTY;

        if (score > bestScore) {
            bestScore = score;
            bestMoves = [move];
        } else if (score === bestScore) {
            bestMoves.push(move);
        }
    }

    if (bestMoves.length > 0) {
        return bestMoves[Math.floor(Math.random() * bestMoves.length)];
    }

    return null;
}

function minimax(depth, alpha, beta, isMaximizing, aiPlayer, humanPlayer) {
    const winner = checkBoardWinner();

    if (winner === aiPlayer) return 100000 + depth;
    if (winner === humanPlayer) return -100000 - depth;
    if (depth === 0 || isBoardFull()) return evaluateBoard(aiPlayer);

    const candidates = getCandidates();

    if (isMaximizing) {
        let maxScore = -Infinity;
        for (const move of candidates) {
            board[move.row][move.col] = aiPlayer;
            const score = minimax(depth - 1, alpha, beta, false, aiPlayer, humanPlayer);
            board[move.row][move.col] = EMPTY;
            maxScore = Math.max(maxScore, score);
            alpha = Math.max(alpha, score);
            if (beta <= alpha) break;
        }
        return maxScore;
    } else {
        let minScore = Infinity;
        for (const move of candidates) {
            board[move.row][move.col] = humanPlayer;
            const score = minimax(depth - 1, alpha, beta, true, aiPlayer, humanPlayer);
            board[move.row][move.col] = EMPTY;
            minScore = Math.min(minScore, score);
            beta = Math.min(beta, score);
            if (beta <= alpha) break;
        }
        return minScore;
    }
}

function getCandidates() {
    const candidates = [];

    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] === EMPTY) {
                let hasNeighbor = false;

                for (let dr = -1; dr <= 1; dr++) {
                    for (let dc = -1; dc <= 1; dc++) {
                        if (dr === 0 && dc === 0) continue;
                        const nr = row + dr;
                        const nc = col + dc;
                        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE &&
                            board[nr][nc] !== EMPTY) {
                            hasNeighbor = true;
                            break;
                        }
                    }
                    if (hasNeighbor) break;
                }

                if (hasNeighbor) {
                    candidates.push({ row, col });
                }
            }
        }
    }

    if (candidates.length === 0 && history.length === 0) {
        return [{ row: 7, col: 7 }];
    }

    if (candidates.length === 0) {
        return [{ row: Math.floor(BOARD_SIZE / 2), col: Math.floor(BOARD_SIZE / 2) }];
    }

    return candidates;
}

function evaluateBoard(aiPlayer) {
    const humanPlayer = aiPlayer === BLACK ? WHITE : BLACK;
    let score = 0;

    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] !== EMPTY) {
                const player = board[row][col];
                const isAI = player === aiPlayer;

                score += evaluatePosition(row, col, player) * (isAI ? 1 : -1);
            }
        }
    }

    return score;
}

function evaluatePosition(row, col, player) {
    const directions = [
        [0, 1], [1, 0], [1, 1], [1, -1]
    ];

    let totalScore = 0;

    for (const [dr, dc] of directions) {
        const line = getLine(row, col, dr, dc);
        const normalizedLine = line.map(cell => {
            if (cell === player) return 1;
            if (cell === EMPTY) return 0;
            return -1;
        });
        totalScore += evaluateLine(normalizedLine);
    }

    return totalScore;
}

function getLine(row, col, dr, dc) {
    const line = [board[row][col]];

    for (let i = 1; i < 5; i++) {
        const nr = row + dr * i;
        const nc = col + dc * i;
        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE) {
            line.push(board[nr][nc]);
        } else {
            line.push(-1);
        }
    }

    for (let i = 1; i < 5; i++) {
        const nr = row - dr * i;
        const nc = col - dc * i;
        if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE) {
            line.unshift(board[nr][nc]);
        } else {
            line.unshift(-1);
        }
    }

    return line;
}

function evaluateLine(line) {
    const patterns = [
        { pattern: [1, 1, 1, 1, 1], score: 100000 },
        { pattern: [0, 1, 1, 1, 1, 0], score: 10000 },
        { pattern: [0, 1, 1, 1, 0, 0], score: 1000 },
        { pattern: [0, 0, 1, 1, 1, 0], score: 1000 },
        { pattern: [1, 1, 0, 1, 1], score: 1000 },
        { pattern: [0, 1, 1, 0, 1, 0], score: 500 },
        { pattern: [0, 1, 0, 1, 1, 0], score: 500 },
        { pattern: [0, 1, 1, 0, 0], score: 100 },
        { pattern: [0, 0, 1, 1, 0], score: 100 },
        { pattern: [1, 0, 1, 0, 1], score: 100 },
        { pattern: [1, 0, 0, 1, 1], score: 50 },
        { pattern: [1, 1, 0, 0, 1], score: 50 },
    ];

    let score = 0;
    const lineStr = line.join(',');

    for (const { pattern, score: patternScore } of patterns) {
        const patternStr = pattern.join(',');
        if (lineStr.includes(patternStr)) {
            score += patternScore;
        }
    }

    return score;
}

function checkBoardWinner() {
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] !== EMPTY && checkWin(row, col, board[row][col])) {
                return board[row][col];
            }
        }
    }
    return null;
}

function isBoardFull() {
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (board[row][col] === EMPTY) return false;
        }
    }
    return true;
}

canvas.addEventListener('click', (event) => {
    if (gameOver || aiThinking) return;

    const pos = getClickPosition(event);
    if (pos && board[pos.row][pos.col] === EMPTY) {
        const player = playerIsBlack ? BLACK : WHITE;

        if (currentPlayer !== player) return;

        if (isOnlineMode) {
            socket.emit('makeMove', { roomId: currentRoomId, row: pos.row, col: pos.col });
        } else {
            if (makeMove(pos.row, pos.col, player)) {
                if (!gameOver) {
                    setTimeout(() => aiMove(), 300);
                }
            }
        }
    }
});

document.getElementById('restart-btn').addEventListener('click', () => {
    if (isOnlineMode) {
        socket.emit('restartGame', currentRoomId);
    } else {
        initBoard();
    }
});

document.getElementById('undo-btn').addEventListener('click', () => {
    if (!isOnlineMode) {
        undo();
    }
});
document.getElementById('change-side-btn').addEventListener('click', changeSide);

document.getElementById('offline-btn').addEventListener('click', () => {
    switchToOfflineMode();
});

document.getElementById('online-btn').addEventListener('click', () => {
    switchToOnlineMode();
});

document.getElementById('create-room-btn').addEventListener('click', createRoom);
document.getElementById('join-room-btn').addEventListener('click', joinRoom);
document.getElementById('leave-room-btn').addEventListener('click', leaveRoom);

function switchToOfflineMode() {
    isOnlineMode = false;
    disconnectSocket();
    document.getElementById('offline-btn').classList.add('active');
    document.getElementById('online-btn').classList.remove('active');
    document.getElementById('online-panel').classList.remove('show');
    document.getElementById('leave-room-btn').style.display = 'none';
    document.getElementById('difficulty-select').style.display = 'inline';
    document.querySelector('.difficulty').style.display = 'block';
    initBoard();
}

function switchToOnlineMode() {
    isOnlineMode = true;
    document.getElementById('online-btn').classList.add('active');
    document.getElementById('offline-btn').classList.remove('active');
    document.getElementById('online-panel').classList.add('show');
    document.getElementById('leave-room-btn').style.display = 'none';
    document.getElementById('difficulty-select').style.display = 'none';
    document.querySelector('.difficulty').style.display = 'none';
    connectSocket();
}

function connectSocket() {
    if (socket) return;

    socket = io(SERVER_URL);

    socket.on('connect', () => {
        updateOnlineStatus('已连接');
    });

    socket.on('disconnect', () => {
        updateOnlineStatus('连接断开');
    });

    socket.on('roomCreated', (data) => {
        currentRoomId = data.roomId;
        isHost = true;
        onlineRole = 'black';
        playerIsBlack = true;
        initBoard();
        updateOnlineStatus('等待对手加入...');
        document.getElementById('room-id').value = currentRoomId;
        document.getElementById('leave-room-btn').style.display = 'inline-block';
    });

    socket.on('joinedRoom', (data) => {
        currentRoomId = data.roomId;
        isHost = false;
        onlineRole = data.role;
        playerIsBlack = data.role === 'black';
        board = data.board;
        currentPlayer = data.currentPlayer;
        updateUI();
        drawBoard();
        updateOnlineStatus('游戏中');
        document.getElementById('leave-room-btn').style.display = 'inline-block';
    });

    socket.on('playerJoined', (data) => {
        board = data.board;
        currentPlayer = data.currentPlayer;
        updateUI();
        drawBoard();
        updateOnlineStatus('游戏中');
    });

    socket.on('moveMade', (data) => {
        board[data.row][data.col] = data.player;
        history.push({ row: data.row, col: data.col, player: data.player });
        currentPlayer = data.currentPlayer;
        updateUI();
        drawBoard();
    });

    socket.on('gameEnd', (data) => {
        board = data.board;
        gameOver = true;
        winner = data.winner;
        updateUI();
        drawBoard();
    });

    socket.on('gameRestarted', (data) => {
        board = data.board;
        currentPlayer = data.currentPlayer;
        gameOver = false;
        winner = null;
        history = [];
        playerIsBlack = onlineRole === 'black';
        updateUI();
        drawBoard();
    });

    socket.on('playerLeft', () => {
        updateOnlineStatus('对手已离开');
        gameOver = true;
        updateUI();
    });

    socket.on('error', (message) => {
        alert(message);
    });
}

function disconnectSocket() {
    if (socket) {
        socket.disconnect();
        socket = null;
    }
}

function createRoom() {
    if (!socket) {
        connectSocket();
        setTimeout(() => {
            socket.emit('createRoom');
        }, 500);
    } else {
        socket.emit('createRoom');
    }
}

function joinRoom() {
    const roomId = document.getElementById('room-id').value.trim();
    if (!roomId) {
        alert('请输入房间号！');
        return;
    }

    if (!socket) {
        connectSocket();
        setTimeout(() => {
            socket.emit('joinRoom', roomId);
        }, 500);
    } else {
        socket.emit('joinRoom', roomId);
    }
}

function leaveRoom() {
    if (socket && currentRoomId) {
        socket.emit('leaveRoom', currentRoomId);
    }
    currentRoomId = null;
    isHost = false;
    onlineRole = null;
    disconnectSocket();
    switchToOfflineMode();
}

function updateOnlineStatus(status) {
    const statusElement = document.getElementById('online-status');
    statusElement.textContent = status;

    statusElement.className = 'online-status';
    if (status.includes('等待')) {
        statusElement.classList.add('waiting');
    } else if (status.includes('游戏')) {
        statusElement.classList.add('playing');
    } else if (status.includes('连接')) {
        statusElement.classList.add('connected');
    }
}

initBoard();